%Linear FIR filter coefficients implemented for multi rate operations 
%performed on OFDM PHY preamble of IEEE 802.11ad Std.

h = [-1,0,1,1,-2,-3,0,5,5,-3,-9,-4,10,14,-1,-20,-16,14,33,9,-35,...
    -42,11,64,40,-50,-96,-15,120,126,-62,-256,-148,360,985,...
    1267,...
    985,360,-148,-256,-62,126,120,-15,-96,-50,40,64,11,-42,...
     -35,9,33,14,-16,-20,-1,14,10,-4,-9,-3,5,5,0,-3,-2,1,1,0,-1];
 
hLen = length(h);

fid = fopen('hfilt_CSD.txt','w');

if fid == -1
    return
end

fprintf(fid,'%s |     %s      |  %s  |  %s  | %s |\n','Coeff','CSD','pos','neg','shift`s');
fprintf(fid,'------|--------------|-------|-------|---------|\n');
for k=1:ceil(hLen/2)
    % Patrick J. Moran
    [csd pos neg]= csdigit(h(k),12);
    shift_ops = length(findstr(csd,'+')) + length(findstr(csd,'-'));
    fprintf(fid,'%5d | %s | %5d | %5d |  %3d    |\n',h(k),csd(1:end-1),pos,neg,shift_ops);    
end
fprintf(fid,'------------------------------------------------');

fclose(fid);

display('done');
